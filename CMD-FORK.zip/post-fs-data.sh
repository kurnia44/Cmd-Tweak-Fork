#!/system/bin/sh
for driver in $(cmd settings list global|grep driver|cut -f1 -d=);do
  cmd settings delete global "$driver"
done