#!/system/bin/sh
MODDIR=/data/adb/modules/cmd_tweaks
[ -n "$AXERON" ]&&a()(sleep 0.01;printf "$@")||a()(sleep 0.01;echo "$@")
PID="$(pgrep -f "sh $MODDIR")" uptime=$(cut -d. -f1 /proc/uptime) memory=$(cat /proc/meminfo|tr -s \ )
a "$MODDIR"
a " "
a "***********************************************"
a "$(grep name= "$MODDIR/module.prop"|cut -f2 -d=) ($(grep version= "$MODDIR/module.prop"|cut -f2 -d=)) by $(grep author= "$MODDIR/module.prop"|cut -f2 -d=)"
a "***********************************************"
a " "
if [ -n "$PID" ];then
  a "- Service ($PID)"
  a "- CPU Usage: $(ps -eo %cpu,pid|grep "$PID"|grep -ov "$PID"|tr -d \ )%%"
  a "- RES Usage: $(ps -eo res,pid|grep "$PID"|grep -ov "$PID"|tr -d \ )"
  a "- SHR Usage: $(ps -eo shr,pid|grep "$PID"|grep -ov "$PID"|tr -d \ )"
  a " "
fi
a "· OS: Android $(getprop ro.build.version.release)"
a "· Model: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
a "· Kernel: $(uname -r|cut -f1,2,3 -d-)"
a "· Uptime: $((uptime/3600)) hour, $((uptime%3600/60)) mins"
a "· Packages: $(cmd package list packages -s --user 0|wc -l) (sys), $(cmd package list packages -3 --user 0|wc -l) (trd)"
a "· Resolution:$(wm size|cut -d: -f2)"
a "· Theme: $(getprop ro.build.fingerprint|tr '/' '\n'|grep user|cut -f1 -d:)"
a "· Terminal: $(cmd activity stack list|grep 0,0.*visible=true|tr -d ' '|cut -f1 -d/|cut -f2 -d:)"
a "· CPU: $(getprop ro.soc.manufacturer) $(getprop ro.soc.model) ($(grep proc /proc/cpuinfo|wc -l)) @ $(cat /sys/devices/system/cpu/cpufreq/*/cpuinfo_max_freq|tail -n1|awk '{printf("%.3f\n",$1/1000000)}')GHz"
a "· GPU:$(dumpsys SurfaceFlinger|grep GLES:|cut -f2 -d,)"
a "· Memory: $((($(echo "$memory"|grep MemTotal|cut -f2 -d\ )-$(echo "$memory"|grep MemAvailable|cut -f2 -d\ ))/1024))MiB / $(($(echo "$memory"|grep MemTotal|cut -f2 -d\ )/1024))MiB"
a " "
if "$AXERON";then
  echo "[-] Open WebUI by clicking the module card."
elif [ -n "$MMRL" ];then
  echo "[-] Open WebUI by clicking the module card."
elif pm path io.github.a13e300.ksuwebui>/dev/null 2>&1;then
  echo "[*] Launching KSU Webui Standanlone.."
  sleep 1
  am start -n "io.github.a13e300.ksuwebui/.WebUIActivity" -e id "cmd_tweaks">/dev/null 2>&1
else
  echo "[!] Install KsuWebUI for WebUI access"
  sleep 1
  am start -a android.intent.action.VIEW -d "https://github.com/5ec1cff/KsuWebUIStandalone/releases">/dev/null 2>&1
fi