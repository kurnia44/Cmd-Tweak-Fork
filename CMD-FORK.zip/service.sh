#!/system/bin/sh
[ -z "$AXERON" ]&&sleep 1m;while [ $(getprop sys.boot_completed) != 1 ];do sleep 5;done
for a in /proc/sys/kernel/*panic*;do echo 0>"$a";done;exec>/dev/null 2>&1;MODDIR=${0%/*}

# fix music player stopped
music="
com.google.android.apps.youtube.music
com.soundcloud.android
com.spotify.lite
com.spotify.music
com.tencent.ibg.joox
deezer.android.app
"

# notification and log
find /storage/emulated/0/ -name *.log -type f -delete
echo "[$(date +%F|sed 's/^20//')]: installing">/storage/emulated/0/Android/cmd_tweaks.log
sosp()(cmd notification post -t CMD-TWEAKS -i file:///storage/emulated/0/Android/media/.cmd.jpg -I file:///storage/emulated/0/Android/media/.cmd.jpg CMD-TWEAKS Installing
su -lp 2000 -c "/system/bin/cmd notification post -t CMD-TWEAKS -i file:///storage/emulated/0/Android/media/.cmd.jpg -I file:///storage/emulated/0/Android/media/.cmd.jpg CMD-TWEAKS Installing"
echo "[$(date +%T)]: $@">>/storage/emulated/0/Android/cmd_tweaks.log)

# temporary performance mode
logcat -G 8m
cmd activity memory-factor set 0
cmd device_config put activity_manager proactive_kills_enabled true
cmd device_config put activity_manager low_swap_threshold_percent 0.25
cmd device_config put activity_manager max_cached_processes 128
cmd device_config put activity_manager max_phantom_processes 256
cmd deviceidle disable
cmd deviceidle unforce
cmd settings put global activity_manager_constants max_cached_processes=64,max_phantom_processes=128,power_check_max_cpu_1=32,power_check_max_cpu_2=32,power_check_max_cpu_3=16,power_check_max_cpu_4=8,power_check_max_cpu_5=8
cmd settings put global game_driver_all_apps 1
cmd settings put global updatable_driver_all_apps 1
cmd thermalservice override-status 0
sosp temporary perf mode

(# ignore delivery group policy
for a in $(cmd package dump android|grep Action:|cut -f2 -d\"|sort|uniq);do
  cmd activity set-ignore-delivery-group-policy "$a"
done
sosp ignore group policy)&

(# inject temperature
for a in $(dumpsys thermalservice|grep -Eo 'mName[^,]+'|cut -f2 -d=|sort|uniq);do
  cmd thermalservice inject-temperature "$a" none "$a" 25
done
sosp inject temperature)&

(# stop monitoring apps
for a in $(ps -eo PID,USER|grep u0_|cut -f1 -du);do
  cmd activity profile stop "$a"
  cmd activity set-watch-heap "$a" 0
done
sosp stop monitoring apps)&

(# disable dropbox
for a in $(cmd settings list secure|grep dropbox|cut -f1 -d=);do
  cmd settings delete secure "$a"
done
cmd dropbox restore-defaults
cmd settings put global dropbox_max_files 0
sosp disable dropbox)&

(# debloat debugging and logging apps
for a in cn.nubia.aftersale com.alcatel.mcrm com.android.huawei.HiMediaEngine com.debug.loggerui com.google.android.apps.carrier.log com.google.android.grilservice com.huaqin.btlogger com.huaqin.clearefs com.huaqin.diaglogger com.huawei.hms5gkit.agentservice com.huawei.hwpolicyservice com.huawei.searchservice com.huawei.smarthome com.ims.dm com.lge.ims.chatbotinfoprovider com.lge.ims.rcsprovider com.lge.imsvt com.mediatek.bluetooth.dtt com.mediatek.mdmlsample com.mediatek.thermalmanager com.miui.securityinputmethod com.motorola.android.nativedropboxagent com.motorola.systemserver com.oem.logkitsdservice com.oem.oemlogkit com.oneplus.commonoverlay.com.oneplus com.oplus.lfeh com.oplus.onetrace com.oplus.powermonitor com.oppo.logkitservice com.qti.diagservices com.qualcomm.qti.perfdump com.qualcomm.qti.trustedui com.samsung.android.sm.provider com.samsung.fresco.logging com.samsung.slsi.audiologging com.samsung.slsi.telephony.silentlogging com.sec.android.app.servicemodeapp com.sec.imslogger com.sec.mldapchecker com.sec.modem.settings com.sonymobile.advancedlogging com.thundercomm.ar.core com.transsion.hamal com.transsion.kolun.aiservice com.vivo.alphacamera com.vivo.devicereg com.vzw.qualitydatalog com.wt.secret_code_manager com.xiaomi.mtb net.oneplus.commonlogtool ohos.media.medialibrary;do
  cmd package install-existing "$a"
  cmd package clear "$a"
  cmd package uninstall "$a"
  cmd package uninstall --user 0 "$a"
  cmd package uninstall -k --user 0 "$a"
done
sosp debloat useless apps)&

(# disable tracing
atrace --async_stop>/dev/null
cmd accessibility stop-trace
cmd activity trace-ipc stop
cmd migard dump-trace false
cmd migard start-trace false
cmd migard stop-trace true
cmd migard trace-buffer-size 0
cmd input_method tracing stop
cmd statusbar tracing stop
cmd window tracing size 0
cmd window tracing stop
echo 0>/sys/kernel/tracing/tracing_on
sosp disable tracing)&

(# devconf tweaks by dcx
cmd device_config set_sync_disabled_for_tests until_reboot
for a in $(cmd device_config list|cut -f1 -d=);do
  cmd device_config delete "${a%/*}" "${a#*/}"
done
. "$MODDIR/other/devconf.sh"
sosp apply devconf by dcx)&

(# clean system junk
for a in $(cmd package list packages --user 0 -s|grep -iv theme|cut -f2 -d:);do
  rm -rf "/storage/emulated/0/Android/data/$a"
  rm -rf "/storage/emulated/0/Android/media/$a"
  rm -rf "/storage/emulated/0/Android/obb/$a"
done
#for b in $(cmd package list packages --user 0|cut -f2 -d:);do cmd package delete-dexopt "$b";done
cmd activity clear-debug-app
cmd activity clear-exit-info
cmd activity clear-watch-heap all
cmd blob_store clear-all-blobs
cmd blob_store clear-all-sessions
cmd companiondevice remove-inactive-associations
cmd device_policy clear-freeze-period-record
cmd font clear
cmd greezer clearmonitor
cmd location_time_zone_manager clear_recorded_provider_states
cmd lock_settings clear
cmd media.camera clear-stream-use-case-override
cmd media.camera watch clear
cmd miui.downscale clear-debug-apps
cmd miui_embedding_window clear-fixedOri
cmd miui_embedding_window_projection clear-fixedOri
cmd safety_center clear-data
cmd stats config remove 0
cmd time_detector clear_network_time
cmd time_detector clear_system_clock_network_time
cmd wifi remove-all-suggestions
dumpsys procstats --clear
find /storage/emulated/0/ -empty -delete
rm -rf /storage/emulated/0/*/.thumbnails
sosp clean system junk)&

(# games configuration
# unreal engine
for a in /storage/emulated/0/Android/data/*/files/UE4Game/*/*;do
  mkdir -p "$a/Saved/Config/Android"
  rm -rf "$a/Saved/Config/Android/DeviceProfiles.ini"
  rm -rf "$a/Saved/Config/Android/Engine.ini"
  rm -rf "$a/Saved/Logs"
  printf "[Android_Low DeviceProfile]\nCVars=sg.AntiAliasingQuality=0\nCVars=sg.EffectsQuality=0\nCVars=sg.FoliageQuality=0\nCVars=sg.GlobalIlluminationQuality=0\nCVars=sg.PostProcessQuality=0\nCVars=sg.ReflectionQuality=0\nCVars=sg.ShadingQuality=0\nCVars=sg.ShadowQuality=0\nCVars=sg.TextureQuality=0\nCVars=sg.ViewDistanceQuality=0\n[Android_Adreno100 DeviceProfile]\nBaseProfileName=Android_Low">"$a/Saved/Config/Android/DeviceProfiles.ini"
  printf "[SystemSettings]\ndp.Override=Android_Adreno830\na.URO.Enable=0\nfoliage.DensityType=0\nr.AmbientOcclusionMaxQuality=0\nr.DetailMode=0\nr.FidelityFX.FSR.RCAS.Sharpness=0.2\nr.FidelityFX.FSR.SecondaryUpscale=1\nr.Kuro.AutoCoolEnable=0\nr.Kuro.Foliage.MobileFarCullDistanceMax=7500\nr.Kuro.Foliage.MobileGrassCullDistanceMax=5000\nr.Kuro.Foliage.MobileImpostorFarCullDistanceMax=25000\nr.Kuro.Foliage.MobileMiddleCullDistanceMax=3750\nr.Kuro.Foliage.MobileNearCullDistanceMax=2000\nr.Kuro.InteractionEffect.UseCppWaterEffect=0\nr.Kuro.KuroBloomStreak=0\nr.KuroMaterialQualityLevel=2\nr.KuroVolumeCloudEnable=0\nr.LandscapeLODBias=1\nr.MaterialQualityLevel=2\nr.Mobile.GTAO.Quality=0\nr.MobileLightShaft.DownSampleFactor=1\nr.ParticleLODBias=1\nr.RayTracing.LoadConfig=0\nr.SSFS=0\nr.SSR.Quality=0\nr.SceneColorFringeQuality=0\nr.Shadow.DistanceScale=0.6\nr.Shadow.ForbidHISMShadowStartIndex=0\nr.Shadow.MaxCSMResolution=256\nr.Shadow.MinResolution=256\nr.Shadow.PerObjectResolutionMax=256\nr.Shadow.PerObjectResolutionMin=256\nr.Shadow.PerObjectShadowMapResolution=256\nr.Shadow.RadiusThreshold=0.06\nr.StaticMeshLODDistanceScale=0.7\nr.TemporalAA.MobileFrameWeight=0.35\nr.TemporalAA.MobileStaticFrameWeight=0.35\nr.TemporalAA.MobileUpsampling=1\nr.Tonemapper.Quality=1\nwp.Runtime.OverrideMultipleRuntimeGridLoadingRangeValues=50&80&180&100&450&1500&150&200&300&150&200&300&480&250&50&80&100&150&40&80&100&100&300&1500&50&80&100&450&600\n[/Script/Engine.RendererOverrideSettings]\ndp.Override=Android_Adreno830\n[/Script/Engine.RendererSettings]\na.URO.Enable=0\nfoliage.DensityType=0\nr.AmbientOcclusionMaxQuality=0\nr.DetailMode=0\nr.FidelityFX.FSR.RCAS.Sharpness=0.2\nr.FidelityFX.FSR.SecondaryUpscale=1\nr.Kuro.AutoCoolEnable=0\nr.Kuro.Foliage.MobileFarCullDistanceMax=7500\nr.Kuro.Foliage.MobileGrassCullDistanceMax=5000\nr.Kuro.Foliage.MobileImpostorFarCullDistanceMax=25000\nr.Kuro.Foliage.MobileMiddleCullDistanceMax=3750\nr.Kuro.Foliage.MobileNearCullDistanceMax=2000\nr.Kuro.InteractionEffect.UseCppWaterEffect=0\nr.Kuro.KuroBloomStreak=0\nr.KuroMaterialQualityLevel=2\nr.KuroVolumeCloudEnable=0\nr.LandscapeLODBias=1\nr.MaterialQualityLevel=2\nr.Mobile.GTAO.Quality=0\nr.MobileLightShaft.DownSampleFactor=1\nr.ParticleLODBias=1\nr.RayTracing.LoadConfig=0\nr.SSFS=0\nr.SSR.Quality=0\nr.SceneColorFringeQuality=0\nr.Shadow.DistanceScale=0.6\nr.Shadow.ForbidHISMShadowStartIndex=0\nr.Shadow.MaxCSMResolution=256\nr.Shadow.MinResolution=256\nr.Shadow.PerObjectResolutionMax=256\nr.Shadow.PerObjectResolutionMin=256\nr.Shadow.PerObjectShadowMapResolution=256\nr.Shadow.RadiusThreshold=0.06\nr.StaticMeshLODDistanceScale=0.7\nr.TemporalAA.MobileFrameWeight=0.35\nr.TemporalAA.MobileStaticFrameWeight=0.35\nr.TemporalAA.MobileUpsampling=1\nr.Tonemapper.Quality=1\nwp.Runtime.OverrideMultipleRuntimeGridLoadingRangeValues=50&80&180&100&450&1500&150&200&300&150&200&300&480&250&50&80&100&150&40&80&100&100&300&1500&50&80&100&450&600">"$a/Saved/Config/Android/Engine.ini"
  touch "$a/Saved/Logs"
done
# genshin impact
b=/storage/emulated/0/Android/data/com.miHoYo.GenshinImpact/files/hardware_model_config.json
c='{\n    "configs": [\n        {\n            "hardwareModel": "*",\n            "littleCoreCount": 0,\n            "bigCoreCount": 8,\n            "littleCoreMask": 255,\n            "bigCoreMask": 0,\n            "vulkanFlag": 0\n        }\n    ]\n}'
rm -rf "$b"
printf "$c"|sed "s/\*/$(getprop ro.product.manufacturer) $(getprop ro.product.model)/g">"$b"
for d in /storage/emulated/0/Android/data/com.miHoYo.GenshinImpact/files/vulkan_gpu_list_config.txt /storage/emulated/0/Android/data/com.miHoYo.GenshinImpact/files/vulkan_gpu_list_config_engine.txt;do
  rm -rf "$d"
  printf "Mali-G720 MC7\n$(dumpsys SurfaceFlinger|grep GLES:|cut -f2 -d,|sed 's/^ //')">"$d"
done
# mobile legends
for e in $(find /storage/emulated/0/Android/data/*/files/dragon2017 -name *record*);do
  rm -rf "$e"
  touch "$e"
done
sosp games configuration)&

(# disable logging
config=$(for b in $(seq 32 126);do printf "\\x$(printf '%x' $b) ";done)
if [ -d /system/lib64 ];then
  getprop="$(strings /*/lib64/*|grep '^debug\.';strings /*/lib64/*/*|grep '^debug\.';strings /*/framework/*|grep '^debug\.';strings /*/framework/*/*|grep '^debug\.';strings /*/framework/*/*/*|grep '^debug\.')"
else
  getprop="$(strings /*/lib/*|grep '^debug\.';strings /*/lib/*/*|grep '^debug\.';strings /*/framework/*|grep '^debug\.';strings /*/framework/*/*|grep '^debug\.';strings /*/framework/*/*/*|grep '^debug\.')"
fi
for a in $(cmd settings list global|cut -f1 -d=|grep logging);do
  cmd settings put global "$a" 0
done
for b in $(cmd settings list secure|cut -f1 -d=|grep logging);do
  cmd settings put secure "$b" 0
done
for c in $(cmd settings list system|cut -f1 -d=|grep logging);do
  cmd settings put system "$c" 0
done
for d in $(echo "$getprop"|grep -v enable|grep -Ei 'log|trace|tracing');do
  setprop "$d" 0
done
for e in $(echo "$getprop"|grep enable|grep -E 'log|trace|tracing');do
  setprop "$e" false
done
for f in $(ps -eo NAME|sort|uniq);do
  cmd activity app-logging "$f" 0 disable-text$config
done
for g in $(echo "$getprop"|grep interval);do
  setprop "$g" "$(echo 2^64|bc)"
done
for h in $(getprop|grep log.tag|cut -f1 -d]|tr -d [);do
  setprop "$h" S
done
cmd activity logging disable-text$config
cmd autofill set log_level off
cmd display ab-logging-disable
cmd display dmd-logging-disable
cmd display dwb-logging-disable
cmd miui_step_counter_service logging-disable
cmd voiceinteraction set-debug-hotword-logging false
cmd wifi set-verbose-logging disabled -l 0
cmd window logging disable
cmd window logging disable-text
cmd window logging stop
logcat --wrap
logcat -P "$(ps -eo %CPU,PID|grep -Ev '%|0.0'|cut -f2 -d.|tr -s \ |cut -f2 -d\ |sed 's/^/~/g')"
sosp disable logging)&

(# optimize all packages
for a in $(cmd package list packages --user 0|grep -v android|cut -f2 -d:) $(cmd package list packages --user 0 google|grep -v ia.mo|cut -f2 -d:);do
  for b in $(cmd package list packages --user 0 -U "$a"|cut -f3 -d:);do
    cmd connectivity set-background-networking-enabled-for-uid "$b" true
    cmd netpolicy add restrict-background-whitelist "$b"
    cmd netpolicy remove restrict-background-blacklist "$b"
    cmd netpolicy add app-idle-whitelist "$b"
  done
  cmd activity clear-ignore-delivery-group-policy "$a"
  cmd activity service-restart-backoff enable "$a"
  cmd activity set-bg-restriction-level --user 0 "$a" restricted_bucket
  cmd activity set-foreground-service-delegate "$a" stop
  cmd activity set-inactive "$a" true
  cmd activity set-standby-bucket "$a" 50
  cmd activity set-standby-bucket "$a" restricted
  cmd app_hibernation set-state "$a" true
  cmd connectivity set-package-networking-enabled false "$a"
  cmd deviceidle whitelist "-$a"
  cmd package art clear-app-profiles "$a"
  cmd package log-visibility --disable "$a"
  cmd sdk_sandbox stop "$a"
  cmd usagestats clear-last-used-timestamps "$a"
  cmd usagestats delete-package-data "$a"
done
for c in $music $(cmd package list packages --user 0 -s android|grep -v google|cut -f2 -d:);do
  cmd activity set-bg-restriction-level --user 0 "$c" unrestricted
  cmd activity set-inactive "$c" false
  cmd activity set-standby-bucket "$c" active
  cmd activity set-standby-bucket "$c" 10
  cmd app_hibernation set-state "$c" false
done
sosp optimize all pkgs)&

(# other cmd tweaks
bmgr cancel backups
bmgr enable 0
cmd activity fgs-notification-rate-limit enable
cmd activity idle-maintenance
cmd activity set-deterministic-uid-idle true
cmd activity untrack-associations
cmd audio reset-sound-dose-timeout
cmd audio set-ringer-mode SILENT
cmd autofill destroy sessions
cmd autofill reset
cmd autofill set max_partitions 0
cmd autofill set max_visible_datasets 0
cmd battery reset
cmd binder_calls_stats --disable
cmd binder_calls_stats --disable-detailed-tracking
cmd binder_calls_stats --reset
cmd blob_store idle-maintenance
cmd connectivity set-chain3-enabled false
cmd content reset-today-stats
cmd content_capture destroy sessions
cmd content_capture set bind-instant-service-allowed false
cmd content_capture set default-service-enabled 0 false
cmd devicestoragemonitor force-not-low
cmd display set-user-disabled-hdr-types 1 2 3 4
cmd greezer enable false
cmd greezer unmonitor 0
cmd jobscheduler trigger-dock-state idle
cmd location_time_zone_manager stop
cmd looper_stats reset
cmd looper_stats disable
cmd media.camera watch stop
cmd media_session dispatch stop
cmd miui.downscale disable-downscale true
cmd miui.downscale set-debug-mode false
cmd miui_step_counter_service disable
cmd miui_step_counter_service trim-all
cmd network_time_update_service reset_server_config_for_tests
cmd otadexopt cleanup
cmd package art cleanup
cmd package set-silent-updates-policy --throttle-time "$(echo 2^62|bc)"
cmd power set-face-down-detector false
cmd print set-bind-instant-service-allowed false
cmd role set-bypassing-role-qualification false
cmd sdk_sandbox set-state --reset
cmd settings put global netstats_enabled 0
cmd shortcut reset-all-throttling
cmd shortcut reset-config
cmd shortcut unload-user
cmd time_zone_detector set_auto_detection_enabled true;cmd time_zone_detector set_auto_detection_enabled false
cmd wearable_sensing destroy-data-stream
cmd wifi reset-connected-score
cmd wifi set-connected-score 60
cmd wifi set-ipreach-disconnect disabled
cmd wifi set-network-selection-config disabled enabled -a 0
cmd wifi set-network-selection-config enabled disabled -a 0
cmd wifi set-scan-always-available disabled
dumpsys batterystats --reset
dumpsys batterystats --reset-all
dumpsys batterystats disable full-history
dumpsys batterystats disable no-auto-reset
dumpsys batterystats disable pretend-screen-off
dumpsys procstats --stop-pretend-screen
dumpsys procstats --stop-testing
mdi_redirector_ctrl --leave-testing-mode
mdi_redirector_ctrl --set-payload-size 0
mdi_redirector_ctrl --stop-monitor
sm idle-maint abort
sosp other cmd tweaks)&

wait # wait until everything is successful

# revert performance mode
for a in $(cmd settings list global|grep driver|cut -f1 -d=);do
  cmd settings delete global "$a"
done
cmd activity memory-factor set 1
cmd deviceidle enable
cmd deviceidle unforce
cmd settings put global activity_manager_constants max_cached_processes=64,max_phantom_processes=128,power_check_max_cpu_1=16,power_check_max_cpu_2=16,power_check_max_cpu_3=8,power_check_max_cpu_4=4,power_check_max_cpu_5=4
cmd thermalservice override-status 1
logcat -G 1m
sosp revert perf mode

# notification and refresh
sosp installed
cmd notification post -t CMD-TWEAKS -i file:///storage/emulated/0/Android/media/.cmd.jpg -I file:///storage/emulated/0/Android/media/.cmd.jpg CMD-TWEAKS Installed
su -lp 2000 -c "/system/bin/cmd notification post -t CMD-TWEAKS -i file:///storage/emulated/0/Android/media/.cmd.jpg -I file:///storage/emulated/0/Android/media/.cmd.jpg CMD-TWEAKS Installed"
exec "$MODDIR/other/loop.sh"