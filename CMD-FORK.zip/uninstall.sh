#!/system/bin/sh
exec>/dev/null 2>&1
for a in $(echo $(cmd settings list global;cmd settings list secure;cmd settings list system)|grep logging|cut -f1 -d=);do
  cmd settings delete global "$a"&
  cmd settings delete secure "$a"&
  cmd settings delete system "$a"&
done
for b in /storage/emulated/0/Android/data/*/files/UE4Game/*/*;do
  rm -rf "$b/Saved/Config/Android/DeviceProfiles.ini"&
  rm -rf "$b/Saved/Config/Android/Engine.ini"&
  rm -rf "$b/Saved/Logs"&
done
for c in $(cmd device_config list|cut -f1 -d=);do
  cmd device_config clear_override "${c%/*}" "${c#*/}"&
  cmd device_config delete "${c%/*}" "${c#*/}"&
done
for d in $(cmd package list packages --user 0|grep -v ia.mo|cut -f2 -d:);do
  cmd activity set-inactive "$d" false&
  cmd app_hibernation set-state "$d" false&
  cmd appops reset "$d"
  cmd deviceidle whitelist "-$d"&
done
for e in cn.nubia.aftersale com.alcatel.mcrm com.android.huawei.HiMediaEngine com.debug.loggerui com.google.android.apps.carrier.log com.google.android.grilservice com.huaqin.btlogger com.huaqin.clearefs com.huaqin.diaglogger com.huawei.hms5gkit.agentservice com.huawei.hwpolicyservice com.huawei.searchservice com.huawei.smarthome com.ims.dm com.lge.ims.chatbotinfoprovider com.lge.ims.rcsprovider com.lge.imsvt com.mediatek.bluetooth.dtt com.mediatek.mdmlsample com.mediatek.thermalmanager com.miui.securityinputmethod com.motorola.android.nativedropboxagent com.motorola.systemserver com.oem.logkitsdservice com.oem.oemlogkit com.oneplus.commonoverlay.com.oneplus com.oplus.lfeh com.oplus.onetrace com.oplus.powermonitor com.oppo.logkitservice com.qti.diagservices com.qualcomm.qti.perfdump com.qualcomm.qti.trustedui com.samsung.android.sm.provider com.samsung.fresco.logging com.samsung.slsi.audiologging com.samsung.slsi.telephony.silentlogging com.sec.android.app.servicemodeapp com.sec.imslogger com.sec.mldapchecker com.sec.modem.settings com.sonymobile.advancedlogging com.thundercomm.ar.core com.transsion.hamal com.transsion.kolun.aiservice com.vivo.alphacamera com.vivo.devicereg com.vzw.qualitydatalog com.wt.secret_code_manager com.xiaomi.mtb net.oneplus.commonlogtool ohos.media.medialibrary;do
  cmd package install-existing "$e"
done
for f in /storage/emulated/0/Android/data/com.miHoYo.GenshinImpact/files/hardware_model_config.json /storage/emulated/0/Android/data/com.miHoYo.GenshinImpact/files/vulkan_gpu_list_config.txt /storage/emulated/0/Android/data/com.miHoYo.GenshinImpact/files/vulkan_gpu_list_config_engine.txt;do
  rm -rf "$f"&
done
for g in $(find /storage/emulated/0/Android/data/*/files/dragon2017 -name *record*);do
  rm -rf "$f"&
done
for h in $(dumpsys game|grep -o "$(cmd package list packages|cut -f2 -d:)");do
  cmd game reset "$h"&
done
cmd device_config set_sync_disabled_for_tests none
cmd deviceidle disable
cmd deviceidle except-idle-whitelist reset
cmd deviceidle unforce
cmd deviceidle sys-whitelist reset
cmd settings delete system light_speed_app
global()(cmd settings delete global "$1")
for driver in $(cmd settings list global|grep driver|cut -f1 -d=);do
  global "$driver"
done
global activity_manager_constants
global netstats_enabled
rm /storage/emulated/0/Android/cmd_tweaks.log
rm /storage/emulated/0/Android/media/.*