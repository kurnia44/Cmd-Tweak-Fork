#!/system/bin/sh
# lowlat_revert_full.sh — Kembalikan semua tweak ke kondisi semula
# Menggunakan STATE yg disimpan oleh lowlat_start_full.sh
# 2025-08-19

set -u

LOG="/data/local/tmp/lowlat_gaming.log"
STATE_DIR="/data/local/tmp/lowlat_state"
STATE_FILE="$STATE_DIR/prev.env"

log(){ echo "[$(date '+%F %T')] $*" | tee -a "$LOG"; }
have(){ command -v "$1" >/dev/null 2>&1; }
need_root(){ id | grep -q 'uid=0' || { log "[!] Jalankan sebagai root (su)"; exit 1; }; }

detect_ifaces(){
  WIFI_IF=""
  CELL_IF=""
  if have ip; then
    for i in $(ip -o link | awk -F': ' '{print $2}'); do
      case "$i" in wlan*|wifi*|wl*) WIFI_IF="$i"; break ;; esac
    done
    for i in $(ip -o link | awk -F': ' '{print $2}'); do
      case "$i" in rmnet*|ccmni*|pdp*|wwan*|rmnet_data*|rmnet_ipa*|seth*|usb_rmnet*) CELL_IF="$i"; break ;; esac
    done
  fi
}

qdisc_clear(){
  dev="$1"; [ -z "$dev" ] && return 0
  have tc || return 0
  tc qdisc del dev "$dev" root 2>>"$LOG" && log "[*] qdisc reset $dev" || true
}

dscp_off(){
  have iptables || return 0
  iptables -t mangle -D POSTROUTING -j LOWLAT 2>/dev/null || true
  iptables -t mangle -F LOWLAT 2>/dev/null || true
  iptables -t mangle -X LOWLAT 2>/dev/null || true
  log "[*] DSCP rules OFF"
}

dns_restore(){
  have settings || return 0
  if [ -f "$STATE_FILE" ]; then
    . "$STATE_FILE"
    if [ "${PREV_DNS_MODE:-}" = "hostname" ] && [ -n "${PREV_DNS_SPEC:-}" ]; then
      settings put global private_dns_mode hostname
      settings put global private_dns_specifier "$PREV_DNS_SPEC"
      log "[*] Private DNS restore → hostname ($PREV_DNS_SPEC)"
    elif [ -n "${PREV_DNS_MODE:-}" ]; then
      settings put global private_dns_mode "$PREV_DNS_MODE"
      if [ "$PREV_DNS_MODE" != "hostname" ]; then
        settings delete global private_dns_specifier 2>/dev/null || true
      fi
      log "[*] Private DNS mode restore → $PREV_DNS_MODE"
    else
      settings put global private_dns_mode opportunistic
      settings delete global private_dns_specifier 2>/dev/null || true
      log "[*] Private DNS → opportunistic (default)"
    fi
  else
    settings put global private_dns_mode opportunistic
    settings delete global private_dns_specifier 2>/dev/null || true
    log "[*] Private DNS → opportunistic (no state)"
  fi
}

wifi_band_restore(){
  have settings || return 0
  if [ -f "$STATE_FILE" ]; then
    . "$STATE_FILE"
    if [ -n "${PREV_WIFI_BAND:-}" ] && [ "${PREV_WIFI_BAND}" != "null" ]; then
      settings put global wifi_frequency_band "$PREV_WIFI_BAND" 2>/dev/null
      log "[*] Wi‑Fi band restore → $PREV_WIFI_BAND"
    else
      settings delete global wifi_frequency_band 2>/dev/null || true
      log "[*] Wi‑Fi band reset (default)"
    fi
  else
    settings delete global wifi_frequency_band 2>/dev/null || true
    log "[*] Wi‑Fi band reset (no state)"
  fi
}

wifi_power_save_on(){
  [ -n "${WIFI_IF:-}" ] || return 0
  have iw || return 0
  iw dev "$WIFI_IF" set power_save on 2>>"$LOG" && log "[*] Wi‑Fi power save ON ($WIFI_IF)" || true
}

perf_off_restore(){
  have cmd || return 0
  # Kita matikan fixed performance; jika ROM awalnya sudah ON, user bisa aktifkan lagi manual.
  cmd power set-fixed-performance-mode-enabled false 2>>"$LOG" && log "[*] Perf mode OFF" || true
  # Tidak mengubah adaptive saver agar tidak bentrok kebijakan OEM
}

# ----- Preferred Network Type restore -----
pref_nt_set(){
  sub="$1"; val="$2"; have cmd || return 1
  cmd phone set-preferred-network-type "$sub" "$val" 2>>"$LOG" && return 0
  case "$val" in
    LTE_ONLY) cmd phone set-preferred-network-type "$sub" 11 2>>"$LOG" || true ;;
    NR_LTE|LTE_NR|NR_ONLY|GSM_WCDMA_LTE|GLOBAL) true ;; # tak ada fallback aman universal
  esac
}
pref_nt_restore(){
  have cmd || return 0
  if [ -f "$STATE_FILE" ]; then
    . "$STATE_FILE"
    # Pulihkan SIM1/SIM2 jika ada info sebelumnya
    if [ -n "${PREV_S1:-}" ] && [ -n "${PREV_NT_SIM1:-}" ]; then
      pref_nt_set "$PREV_S1" "$PREV_NT_SIM1" && log "[*] Restore NT SIM1 (subId=$PREV_S1 → $PREV_NT_SIM1)" || log "[i] Restore NT SIM1 gagal"
    fi
    if [ -n "${PREV_S2:-}" ] && [ -n "${PREV_NT_SIM2:-}" ]; then
      pref_nt_set "$PREV_S2" "$PREV_NT_SIM2" && log "[*] Restore NT SIM2 (subId=$PREV_S2 → $PREV_NT_SIM2)" || log "[i] Restore NT SIM2 gagal"
    fi
  else
    log "[i] STATE tidak ditemukan; lewati restore Preferred Network Type"
  fi
}

# -------------- MAIN --------------
need_root
detect_ifaces
log "[*] Interface: WIFI=${WIFI_IF:-none} CELL=${CELL_IF:-none}"

# Bersihkan qdisc & DSCP
[ -n "${WIFI_IF:-}" ] && qdisc_clear "$WIFI_IF"
[ -n "${CELL_IF:-}" ] && qdisc_clear "$CELL_IF"
dscp_off

# Kembalikan konfigurasi
dns_restore
wifi_band_restore
wifi_power_save_on
perf_off_restore
pref_nt_restore

log "[✓] REVERT full selesai. (STATE: $STATE_FILE)"
exit 0