#!/system/bin/sh
# lowlat_start_full.sh — Aktifkan profil latensi rendah (Android, root)
# Fitur: fq_codel, DSCP EF (UDP kecil), Private DNS, Wi‑Fi tweaks, perf mode,
#        LTE-only (opsional), sim preset (auto/sim1/sim2), simpan STATE utk revert.
# 2025-08-19

set -u

# ============ CONFIG ==========================
PRIVATE_DNS_HOST="one.one.one.one"   # ganti ke dns.google bila mau
USE_DSCP_EF_UDP=1                    # 1=tag UDP kecil (<=256B) ke DSCP EF
FORCE_WIFI_5GHZ=1                    # 1=prefer 5GHz (jika ROM dukung)
BOOST_PERF_MODE=1                    # 1=aktifkan fixed performance mode

APPLY_LTE_ONLY_ON_START=0            # 1=paksa LTE untuk SIM data saat start
LTE_ONLY_TARGET="auto"               # auto|sim1|sim2 (dipakai kalau APPLY_LTE_ONLY_ON_START=1)
# ==============================================

LOG="/data/local/tmp/lowlat_gaming.log"
STATE_DIR="/data/local/tmp/lowlat_state"
STATE_FILE="$STATE_DIR/prev.env"
mkdir -p /data/local/tmp "$STATE_DIR" 2>/dev/null

log(){ echo "[$(date '+%F %T')] $*" | tee -a "$LOG"; }
have(){ command -v "$1" >/dev/null 2>&1; }
need_root(){ id | grep -q 'uid=0' || { log "[!] Jalankan sebagai root (su)"; exit 1; }; }

# ---------- Deteksi interface ----------
detect_ifaces(){
  WIFI_IF=""
  CELL_IF=""
  if have ip; then
    # Wi‑Fi
    for i in $(ip -o link | awk -F': ' '{print $2}'); do
      case "$i" in wlan*|wifi*|wl*) WIFI_IF="$i"; break ;; esac
    done
    # Seluler
    for i in $(ip -o link | awk -F': ' '{print $2}'); do
      case "$i" in rmnet*|ccmni*|pdp*|wwan*|rmnet_data*|rmnet_ipa*|seth*|usb_rmnet*) CELL_IF="$i"; break ;; esac
    done
  fi
}

# ---------- fq_codel ----------
qdisc_apply(){
  dev="$1"; [ -z "$dev" ] && return 0
  have tc || { log "[i] tc tidak ada, skip qdisc"; return 0; }
  tc qdisc replace dev "$dev" root fq_codel target 5ms interval 100ms limit 1000 noecn 2>>"$LOG" \
    && log "[*] fq_codel ON di $dev" || log "[i] Gagal set fq_codel di $dev"
}

# ---------- DSCP EF (UDP kecil) ----------
dscp_on(){
  [ "$USE_DSCP_EF_UDP" -eq 1 ] || return 0
  have iptables || { log "[i] iptables tidak ada, skip DSCP"; return 0; }
  iptables -t mangle -N LOWLAT 2>/dev/null || true
  iptables -t mangle -F LOWLAT
  iptables -t mangle -A LOWLAT -p udp -m length --length 0:256 -j DSCP --set-dscp-class EF
  iptables -t mangle -C POSTROUTING -j LOWLAT 2>/dev/null || iptables -t mangle -A POSTROUTING -j LOWLAT
  log "[*] DSCP EF untuk UDP kecil diaktifkan"
}

# ---------- Private DNS ----------
dns_save_current(){
  have settings || return 0
  CUR_MODE="$(settings get global private_dns_mode 2>/dev/null)"
  CUR_SPEC="$(settings get global private_dns_specifier 2>/dev/null)"
  echo "PREV_DNS_MODE=${CUR_MODE}" >> "$STATE_FILE"
  echo "PREV_DNS_SPEC=${CUR_SPEC}" >> "$STATE_FILE"
}
dns_set_host(){
  have settings || { log "[i] settings tidak ada, skip Private DNS"; return 0; }
  settings put global private_dns_mode hostname
  settings put global private_dns_specifier "$PRIVATE_DNS_HOST"
  log "[*] Private DNS → $PRIVATE_DNS_HOST"
}

# ---------- Wi‑Fi tweaks ----------
wifi_save_band(){
  have settings || return 0
  PREV_BAND="$(settings get global wifi_frequency_band 2>/dev/null)"
  echo "PREV_WIFI_BAND=${PREV_BAND}" >> "$STATE_FILE"
}
wifi_power_save_off(){
  [ -n "${WIFI_IF:-}" ] || return 0
  have iw || { log "[i] iw tidak ada, skip wifi power save"; return 0; }
  iw dev "$WIFI_IF" set power_save off 2>>"$LOG" && log "[*] Wi‑Fi power save OFF ($WIFI_IF)" || true
}
wifi_force_5g(){
  [ "$FORCE_WIFI_5GHZ" -eq 1 ] || return 0
  have settings || return 0
  settings put global wifi_frequency_band 2 2>>"$LOG" && log "[*] Prefer 5 GHz Wi‑Fi" || true
}

# ---------- Perf mode ----------
perf_save_state(){
  have cmd || return 0
  # Tidak semua ROM expose getter; kita simpan flag kita sendiri saja
  echo "PREV_PERF_SET=unknown" >> "$STATE_FILE"
}
perf_on(){
  [ "$BOOST_PERF_MODE" -eq 1 ] || return 0
  have cmd || return 0
  cmd power set-fixed-performance-mode-enabled true 2>>"$LOG" && log "[*] Perf mode ON" || true
  cmd power set-adaptive-power-saver-enabled false 2>>"$LOG" || true
}

# ---------- SIM / Preferred Network Type ----------
get_subids(){
  DUMP="$(cmd phone status 2>/dev/null || dumpsys telephony.registry 2>/dev/null)"
  SUB1="$(echo "$DUMP" | grep -Eo 'slot 0.*subId=[0-9]+' | head -n1 | grep -Eo '[0-9]+')"
  SUB2="$(echo "$DUMP" | grep -Eo 'slot 1.*subId=[0-9]+' | head -n1 | grep -Eo '[0-9]+')"
  DATA="$(cmd phone get-default-data-subscription-id 2>/dev/null | tr -d '\r' | tail -n1)"
  [ -z "${DATA:-}" ] && DATA="$(echo "$DUMP" | grep -Eo 'activeDataSubId=[0-9]+' | head -n1 | cut -d= -f2)"
  echo "$SUB1|$SUB2|$DATA"
}
pref_nt_get(){
  sub="$1"; have cmd || { echo ""; return; }
  cmd phone get-preferred-network-type "$sub" 2>/dev/null | tr -d '\r'
}
pref_nt_set(){
  sub="$1"; val="$2"; have cmd || return 1
  cmd phone set-preferred-network-type "$sub" "$val" 2>>"$LOG" && return 0
  # fallback LTE_ONLY = 11
  [ "$val" = "LTE_ONLY" ] && cmd phone set-preferred-network-type "$sub" 11 2>>"$LOG" || true
}
save_pref_nt_all(){
  IFS="|" read -r S1 S2 SDATA <<EOF
$(get_subids)
EOF
  [ -n "${S1:-}" ] && echo "PREV_NT_SIM1=$(pref_nt_get "$S1")" >> "$STATE_FILE"
  [ -n "${S2:-}" ] && echo "PREV_NT_SIM2=$(pref_nt_get "$S2")" >> "$STATE_FILE"
  [ -n "${SDATA:-}" ] && echo "PREV_NT_DATA_SUB=$SDATA" >> "$STATE_FILE"
  echo "PREV_S1=${S1:-}" >> "$STATE_FILE"
  echo "PREV_S2=${S2:-}" >> "$STATE_FILE"
}
lte_only_apply(){
  IFS="|" read -r S1 S2 SDATA <<EOF
$(get_subids)
EOF
  case "$LTE_ONLY_TARGET" in
    auto)
      [ -n "${SDATA:-}" ] && { pref_nt_set "$SDATA" LTE_ONLY && log "[*] LTE-only data subId=$SDATA"; } || log "[i] Data subId tidak ditemukan"
      ;;
    sim1)
      [ -n "${S1:-}" ] && { pref_nt_set "$S1" LTE_ONLY && log "[*] LTE-only SIM1 (subId=$S1)"; } || log "[i] SIM1 subId tidak ada"
      ;;
    sim2)
      [ -n "${S2:-}" ] && { pref_nt_set "$S2" LTE_ONLY && log "[*] LTE-only SIM2 (subId=$S2)"; } || log "[i] SIM2 subId tidak ada"
      ;;
  esac
}

# -------------- MAIN --------------
need_root
: > "$STATE_FILE"   # reset state file

detect_ifaces
log "[*] Interface: WIFI=${WIFI_IF:-none} CELL=${CELL_IF:-none}"

# Simpan state dulu (supaya bisa direvert)
dns_save_current
wifi_save_band
perf_save_state
save_pref_nt_all

# Terapkan tweak
[ -n "${WIFI_IF:-}" ] && qdisc_apply "$WIFI_IF"
[ -n "${CELL_IF:-}" ] && qdisc_apply "$CELL_IF"
dscp_on
dns_set_host
wifi_power_save_off
wifi_force_5g
perf_on

if [ "$APPLY_LTE_ONLY_ON_START" -eq 1 ]; then
  lte_only_apply
else
  log "[i] LTE-only tidak diaktifkan otomatis (APPLY_LTE_ONLY_ON_START=0)"
fi

log "[✓] START full selesai. STATE tersimpan di $STATE_FILE"
exit 0