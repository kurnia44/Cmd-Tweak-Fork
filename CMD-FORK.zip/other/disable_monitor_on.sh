#!/system/bin/sh
for a in $(find /storage/emulated/0/Android/data/*/files/dragon2017|grep -Ei 'record|history');do rm -rf "$a";touch "$a"&done

# Baris baru untuk membuat file penanda
touch /data/adb/modules/cmd_tweaks/other/ml_monitor_disabled
