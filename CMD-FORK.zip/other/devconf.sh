#https://t.me/dcx402/20
for key in adservice_system_service_enabled cobalt_logging_enabled enable_logged_topic adservice_error_logging_enabled measurement_enable_app_package_name_logging measurement_enable_source_debug_report fledge_app_package_name_logging fledge_auction_server_enable_debug_reporting fledge_auction_server_api_usage_metrics_enabled fledge_auction_server_enabled_for_report_event fledge_auction_server_enabled_for_report_impression fledge_auction_server_enabled_for_select_ads_mediation
do device_config put adservices $key false
done

#https://t.me/dcx402/22
for key in measurement_verbose_debug_reporting_job_required_network_type measurement_debug_reporting_fallback_job_required_network_type measurement_debug_reporting_job_required_network_type measurement_aggregate_fallback_reporting_job_required_network_type measurement_aggregate_reporting_job_required_network_type measurement_async_registration_fallback_job_required_network_type measurement_async_registration_queue_job_required_network_type measurement_event_fallback_reporting_job_required_network_type measurement_event_reporting_job_required_network_type
do device_config put adservices $key 0
done

#https://t.me/dcx402/33
device_config put runtime_native metrics.reporting-mods 0
device_config put runtime_native metrics.reporting-mods-server 0
device_config put runtime_native metrics.reporting-num-mods 0
device_config put runtime_native metrics.reporting-num-mods-server 0

#https://t.me/dcx402/34
for dcx in odp_enable_client_error_logging fcp_enable_client_error_logging odp_background_jobs_logging_enabled fcp_enable_background_jobs_logging
do device_config put on_device_personalization $dcx false
done

#https://t.me/dcx402/38
for dcx in westworld_logging log_error_model_id_westworld_enabled log_model_id_westworld log_model_version_westworld log_classification_latency_westworld moirai_additional_metrics_enabled mismatch_metrics_v2_enabled
do device_config put odad $dcx false
done

#https://t.me/dcx402/41
device_config put activity_manager fgs_start_allowed_log_sample_rate 0
device_config put activity_manager fgs_start_denied_log_sample_rate 0

#https://t.me/dcx402/52
for dcx in Logging__enable_aiai_clearcut_logging AutofillVC__enable_clearcut_log Captions__enable_clearcut_logging PlatformLogging__enable_metric_wise_populations Superpacks__use_logging_listener Overview__enable_pir_clearcut_logging Overview__enable_pir_westworld_logging
do device_config put device_personalization_services $dcx false
done

#https://t.me/dcx402/59
device_config put runtime_native metrics.write-to-statsd false
device_config put runtime_native metrics.reporting-spec ''
device_config put runtime_native metrics.reporting-spec-server ''

#https://t.me/dcx402/67
for dcx in StatsLog__active_users_logger_enabled StatsLog__active_users_logger_non_persistent StatsLog__enable_new_logger_api
do device_config put device_personalization_services $dcx false
done

#https://t.me/dcx402/69
for dcx in odp_background_job_sampling_logging_rate fcp_background_job_logging_sampling_rate
do device_config put on_device_personalization $dcx 0
done

#https://t.me/dcx402/72
device_config put window_manager system_gesture_exclusion_log_debounce_millis 0

#https://t.me/dcx402/74
for dcx in mdd_android_sharing_sample_interval mdd_api_logging_sample_interval mdd_default_sample_interval mdd_download_events_sample_interval mdd_group_stats_logging_sample_interval mdd_mobstore_file_service_stats_sample_interval mdd_network_stats_logging_sample_interval mdd_storage_stats_logging_sample_interval
do device_config put adservices $dcx $(echo 2^64|bc)
done

#https://t.me/dcx402/75
for dcx in AicModels__network_stats_log_sample_interval AicModels__group_stats_log_sample_interval AicModels__storage_stats_log_sample_interval AicModels__api_log_sample_interval AicModels__default_log_sample_interval
do device_config put aicore $dcx $(echo 2^64|bc)
done

#https://t.me/dcx402/76
for dcx in measurement_job_aggregate_fallback_reporting_kill_switch measurement_job_aggregate_reporting_kill_switch measurement_job_event_fallback_reporting_kill_switch measurement_job_event_reporting_kill_switch
do device_config put adservices $dcx true
done

#https://t.me/dcx402/80
device_config put latency_tracker enabled false
device_config put latency_tracker sampling_interval $(echo 2^64|bc)
device_config put latency_tracker action_show_voice_interaction_enable false
device_config put latency_tracker action_show_voice_interaction_sample_interval $(echo 2^64|bc)

#https://t.me/dcx402/173
device_config put textclassifier smart_select_animation_enabled false

#https://t.me/dcx402/198
for k in measurement_flex_api_max_event_reports measurement_flex_api_max_event_report_windows
do device_config put adservices $k 0
done

#https://t.me/dcx402/210
for a in logcat_read_timeout_millis dumpsys_read_timeout_millis logcat_proc_timeout_millis dumpsys_proc_timeout_millis max_logcat_lines_low_mem max_logcat_lines
do device_config put telephony $a 0
done

# Stop log rate (https://t.me/dcx4020/6)
for key in fgs_start_allowed_log_sample_rate fgs_start_denied_log_sample_rate fgs_atom_sample_rate compact_statsd_sample_rate freeze_statsd_sample_rate
do device_config put activity_manager "$key" 0
done

# Stop monitor in background (https://t.me/dcx4020/14)
for a in bg_current_drain_monitor_enabled bg_fgs_monitor_enabled bg_media_session_monitor_enabled bg_permission_monitor_enabled bg_broadcast_monitor_enabled bg_bind_svc_monitor_enabled
do device_config put activity_manager $a false
done

#https://t.me/dcx4020/22 (Reduce Some netstats)
device_config put tethering netstats_store_files_in_apexdata false
device_config put tethering netstats_import_legacy_target_attempts 0

#https://t.me/dcx4020/24 (Reduce some logging/overhead)
for dcx in mdd_logger_kill_switch background_jobs_logging_kill_switch mdd_background_task_kill_switch global_kill_switch
do device_config put adservices $dcx true
done

#https://t.me/dcx4020/29 (Disable App Profiler)
device_config put activity_manager disable_app_profiler_pss_profiling true

#https://t.me/dcx4020/30 (Stop jank monitor)
device_config put interaction_jank_monitor enabled false
device_config put interaction_jank_monitor sampling_interval $(echo 2^64|bc)
device_config put interaction_jank_monitor trace_threshold_frame_time_millis -1
device_config put interaction_jank_monitor trace_threshold_missed_frames -1

#https://t.me/dcx4020/39 (zero log history and buffer size)
device_config put content_capture log_history_size 0
device_config put content_capture max_buffer_size 0

#https://t.me/dcx4012/62 (disable generic event logging)
device_config put settings_ui event_logging_enabled false

#https://t.me/dcx4012/523 (disable media metric)
device_config put media media_metrics_mode 0

#https://t.me/dcx4012/676 (settings low swap threshold percent)
device_config put activity_manager proactive_kills_enabled true
device_config put activity_manager low_swap_threshold_percent 0.5

#https://t.me/dcx4012/733 (boot faster)
device_config put runtime_native_boot iorap_readahead_enable true
device_config put runtime_native_boot iorap_perfetto_enable false

#https://t.me/dcx4012/880 (enabling compaction)
device_config put activity_manager use_compaction true

#https://t.me/dcx4012/893 (settings max processes in memory)
device_config put activity_manager max_cached_processes 64
device_config put activity_manager max_phantom_processes 128

#https://t.me/dcx4012/1100 (can help save battery)
device_config put activity_manager bg_auto_restrict_abusive_apps true
device_config put activity_manager bg_current_drain_auto_restrict_abusive_apps_enabled true