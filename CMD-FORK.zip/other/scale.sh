a="$(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)"
b="$(getprop ro.build.version.release)"
for c in $(dumpsys game|grep -o "$(cmd package list packages --user 0|cut -f2 -d:)");do
  cmd device_config put game_overlay "$c" mode=2,downscaleFactor="$1",useAngle=false,fps="$a",loadingBoost="$(echo 2^30|bc)"
  if [ "$b" = 13 ];then
    cmd game set --mode 2 --downscale "$1" --fps "$a" "$c"
  elif [ "$b" -gt 13 ];then
    cmd game mode 2 "$c"
  fi
done