#!/system/bin/sh
for a in $(find /storage/emulated/0/Android/data/*/files/dragon2017|grep -Ei 'record|history');do rm -rf "$a";done

# Baris baru untuk menghapus file penanda
rm -f /data/adb/modules/cmd_tweaks/other/ml_monitor_disabled
