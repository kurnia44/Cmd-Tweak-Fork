#!/system/bin/sh
exec>/dev/null 2>&1
file_limit="$(($(cat /proc/meminfo|grep MemTotal|grep -o '[0-9]'|tr -d '\n')/(64*513)))"
while :;do

  # check top app
  top_app="$(cmd activity stack list|awk -F'[:/ ]' '/0,0.*visible=true/{a=$5}END{print a}')"

  # check current app
  if [ "$current_app" != "$top_app" ];then current_app="$top_app"

    # check playing game
    if grep -o "$top_app" "${0%/*}/perflist.txt";then

      # auto preload
      su -lp 2000 -c "cmd notification post -t Preloading -i file:///storage/emulated/0/Android/media/.apl.jpg -I file:///storage/emulated/0/Android/media/.apl.jpg preload $top_app"
      cmd notification post -t Preloading -i file:///storage/emulated/0/Android/media/.apl.jpg -I file:///storage/emulated/0/Android/media/.apl.jpg preload $top_app
      for package_assets in $(find "/data/user/0/$top_app" "/storage/emulated/0/Android/data/$top_app" "$(dumpsys package "$top_app"|grep -o codePath=.*|sed 's/codePath=//')" -type f -exec du -b {} +|sort -n|tail -n$file_limit|awk '{$1="";sub(/^/,"");print}');do
        dd if="$package_assets" of=/dev/null bs=1M
      done
      su -lp 2000 -c "cmd notification post -t Preloaded -i file:///storage/emulated/0/Android/media/.apl.jpg -I file:///storage/emulated/0/Android/media/.apl.jpg preload $top_app"
      cmd notification post -t Preloaded -i file:///storage/emulated/0/Android/media/.apl.jpg -I file:///storage/emulated/0/Android/media/.apl.jpg preload $top_app
      # auto preload

      # automatic mode
      if [ "$current_mode" != "performance" ];then current_mode="performance"
        cmd activity memory-factor set 0
        #cmd power set-adaptive-power-saver-enabled false
        #cmd power set-fixed-performance-mode-enabled true
        #cmd power set-mode 0
        cmd settings put global angle_gl_driver_selection_pkgs "$top_app"
        cmd settings put global angle_gl_driver_selection_values native
        cmd settings put global game_driver_opt_in_apps "$top_app"
        cmd settings put global updatable_driver_production_opt_in_apps "$top_app"
        cmd thermalservice override-status 0
        logcat -G 8m
        su -lp 2000 -c "cmd notification post -t Improved -i file:///storage/emulated/0/Android/media/.sai.jpg -I file:///storage/emulated/0/Android/media/.sai.jpg shai device\ performance"
        cmd notification post -t Improved -i file:///storage/emulated/0/Android/media/.sai.jpg -I file:///storage/emulated/0/Android/media/.sai.jpg mode device\ performance
      fi
    else
      if [ "$current_mode" != "powersave" ];then current_mode="powersave"
        for driver in $(cmd settings list global|grep driver|cut -f1 -d=);do
          cmd settings delete global "$driver"
        done
        cmd activity compact system
        cmd activity force-stop com.android.shell
        cmd activity memory-factor set 1
        #cmd power set-adaptive-power-saver-enabled true
        #cmd power set-fixed-performance-mode-enabled false
        #cmd power set-mode 1
        cmd thermalservice override-status 1
        logcat -G 1m
        su -lp 2000 -c "cmd notification post -t Profile: -i file:///storage/emulated/0/Android/media/.sai.jpg -I file:///storage/emulated/0/Android/media/.sai.jpg shai standard"
        cmd notification post -t Profile: -i file:///storage/emulated/0/Android/media/.sai.jpg -I file:///storage/emulated/0/Android/media/.sai.jpg mode standard

      fi
      # automatic mode

    fi
    # check playing game

    # run in every 1 minute
    current_minute="$(date +%M)"
    if [ "$current_minute" != "$minute" ];then minute="$current_minute"

      # minimize logging
      logcat -P "$(ps -eo %CPU,PID|grep -Ev '%|0.0'|cut -f2 -d.|tr -s \ |cut -f2 -d\ |sed 's/^/~/g')"
      logcat --wrap
      logcat -c
      pkill -f dumpsys logcat
      # minimize logging

      # minimize used memory from all running apps
      ps -eo PID,USER|awk '/u0_/{print $1}'|while read process_id;do
        cmd activity profile stop "$process_id"
        cmd activity set-watch-heap "$process_id" 0
      done
      # minimize used memory from all running apps

      # wifi priority
      cmd wifi reset-connected-score
      cmd wifi set-connected-score 60
      # wifi priority

    fi
    # run in every 1 minute

    # light speed app (xiaomi)
    cmd settings put system light_speed_app "$top_app"
    # light speed app (xiaomi)

  fi
  # check current app

  # run in every 3am
  if [ "$(date +%H)" = 03 ];then
    sm fstrim

    sleep 1h
  fi
  # run in every 3am

  # reduce cpu load
  iorenice $$ 7 idle
  renice -n 19 -p $$
  taskset -ap 1 $$
  sleep 10
  # reduce cpu load

done